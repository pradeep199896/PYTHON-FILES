def my_func():
	print("Hey I am in mymodule.py")